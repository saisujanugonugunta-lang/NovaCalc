const expressionEl=document.getElementById('expression'),resultEl=document.getElementById('result'),historyEl=document.getElementById('history');
let expr='',lastResult=null;
const fmt=n=>Number.isInteger(n)?String(n):String(Number(n.toFixed(10)));
function render(){expressionEl.textContent=expr.replaceAll('*','×').replaceAll('/','÷');resultEl.textContent=lastResult!==null&&!expr?fmt(lastResult):expr||'0'}
function safeEvaluate(s){if(!/^[0-9+\-*/%.() ]+$/.test(s))throw Error('Invalid expression');s=s.replace(/(\d+(?:\.\d+)?)%/g,'($1/100)');return Function('"use strict";return ('+s+')')()}
function calculate(){if(!expr)return;try{const value=safeEvaluate(expr);if(!Number.isFinite(value))throw Error();lastResult=value;addHistory(expr,value);expr='';render()}catch{resultEl.textContent='Error';setTimeout(render,800)}}
function addHistory(e,r){const row=document.createElement('div');row.className='history-item';row.innerHTML=`<span><small>${e.replaceAll('*','×').replaceAll('/','÷')}</small></span><strong>${fmt(r)}</strong>`;if(historyEl.classList.contains('history-empty'))historyEl.innerHTML='';historyEl.classList.remove('history-empty');historyEl.prepend(row)}
document.querySelector('.keys').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const value=b.dataset.value,action=b.dataset.action;if(action==='clear'){expr='';lastResult=null;render()}else if(action==='backspace'){expr=expr.slice(0,-1);render()}else if(action==='equals')calculate();else if(value){if(lastResult!==null&&!expr&&/[0-9.]/.test(value))lastResult=null;expr+=value;render()}});
document.addEventListener('keydown',e=>{if(/[0-9.+\-*/%]/.test(e.key)){expr+=e.key;render()}else if(e.key==='Enter'||e.key==='=')calculate();else if(e.key==='Backspace'){expr=expr.slice(0,-1);render()}else if(e.key==='Escape'){expr='';lastResult=null;render()}});
document.getElementById('clearHistory').onclick=()=>{historyEl.className='history-empty';historyEl.textContent='No calculations yet.'};
document.getElementById('themeBtn').onclick=()=>document.body.classList.toggle('dark');
render();
