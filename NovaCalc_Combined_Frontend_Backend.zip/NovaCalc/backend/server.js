const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

function evaluate(expression) {
  if (
    typeof expression !== "string" ||
    expression.length > 200 ||
    !/^[0-9+\-*/%.() ]+$/.test(expression)
  ) {
    throw new Error("Invalid expression");
  }

  expression = expression.replace(
    /(\d+(?:\.\d+)?)%/g,
    "($1/100)"
  );

  const result = Function(
    '"use strict"; return (' + expression + ")"
  )();

  if (!Number.isFinite(result)) {
    throw new Error("Invalid result");
  }

  return result;
}

app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    app: "NovaCalc"
  });
});

app.post("/api/calculate", (req, res) => {
  try {
    const expression = req.body.expression;
    const result = evaluate(expression);

    res.json({
      success: true,
      expression,
      result
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message
    });
  }
});

app.listen(PORT, () => {
  console.log(`NovaCalc backend running on port ${PORT}`);
});
